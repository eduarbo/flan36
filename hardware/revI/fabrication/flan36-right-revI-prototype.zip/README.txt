FLAN36 revI prototype candidate — right
Two copper layers, 1.6 mm FR4, nominal 1 oz copper. Internal routed cutouts on Edge.Cuts.
No panelization or assembly service is specified. Inspect Gerber and drill previews.
Digital DRC/ERC/netlist checks passed. This is not a physically qualified build kit.
Check exact connectors, cell dimensions/polarity, printed fit and retention before ordering.
Build, BOM and hardware acceptance: https://github.com/eduarbo/flan36/blob/main/docs/build.md
